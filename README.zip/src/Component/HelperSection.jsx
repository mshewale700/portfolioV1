import React from 'react'

function HelperSection() {
  return (
    <div className='h-[100vh]'></div>
  )
}

export default HelperSection