import React from 'react'
 import { motion } from "framer-motion";
import {fade} from '../../FramerMotion/variants'
const AllExpriance = () => {
  
  return (
    <div> 

    </div>
  )
}

export default AllExpriance