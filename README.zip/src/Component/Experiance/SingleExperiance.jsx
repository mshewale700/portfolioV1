import React from 'react'

const SingleExperiance = () => {
  return (
    <div>SingleExperiance</div>
  )
}

export default SingleExperiance